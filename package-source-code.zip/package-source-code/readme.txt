Steps to run:

1) We are using vue to build the screens, so you need to run the Node Package Manager to compile the code.
2) Go to the Terminal and navigate to the source code.

3) Run the command
$> npm run production

4) This will build the dist/popup.js file from compiled Vue templates.
5) Now you can run the extension