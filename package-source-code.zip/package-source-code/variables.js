var OPTIONS = {
    // baseurl: "http://gitworkdone.test",
    // apiurl:  "http://gitworkdone.test/api/v1"
    baseurl: "https://sandbox.app.gitcommits.com",
    apiurl:  "https://sandbox.app.gitcommits.com/api/v1"
};