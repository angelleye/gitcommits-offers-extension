var OPTIONS = {
    baseurl: "https://app.gitcommits.com",
    apiurl:  "https://app.gitcommits.com/api/v1"
};